package Array;


import java.util.Arrays;


public class BubbleSort {
     int [] bubble ;
    public BubbleSort(int data[]) {
        this.bubble = Arrays.copyOf(data, data.length);
    }
    public int[] BubbleSort() {
        for(int j = 1; j<bubble.length;j++){
            for(int i = bubble.length-1; i>0; i--){
                        int a = bubble[i];
                        int b = bubble[i-1];
                        if (a<b){
                            bubble[i]=b;
                            bubble[i-1]=a;
                }
            }
        }            
        return bubble;

    }
}

