package Array;

import java.net.URL;
import java.util.Arrays;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class ContohArray1Controller implements Initializable{

    @FXML
    private TableView<String> tabelNamaBuah, tabelNamaBuah2;

    @FXML
    private TableColumn<String, String> kolomNamaBuah, kolomNamaBuah2;

    @FXML
    private TextField textNamaBuah;

    @Override
    public void initialize (URL url, ResourceBundle rb){
        kolomNamaBuah.setCellValueFactory(data -> 
        new SimpleStringProperty(data.getValue()));
        
        kolomNamaBuah2.setCellValueFactory(data -> 
        new SimpleStringProperty(data.getValue()));
    }
    @FXML
    public void tambahData(){
        String namaBuah = textNamaBuah.getText();
        tabelNamaBuah.getItems().add(namaBuah);
        textNamaBuah.clear();
    }
    @FXML
    public void hapusData(){
        int indexTerpilih = tabelNamaBuah.getSelectionModel().getSelectedIndex();
        tabelNamaBuah.getItems().remove(indexTerpilih);
        int indexTerpilih2 = tabelNamaBuah2.getSelectionModel().getSelectedIndex();
        tabelNamaBuah2.getItems().remove(indexTerpilih);
    }
    @FXML
    public void ascendingData(){
    // TableColumn<String, String> column = kolomNamaBuah; // column you want

      //  List<String> columnData = new ArrayList<>();
      //  for (String item : tabelNamaBuah.getItems()) {
      //  columnData.add(kolomNamaBuah.getCellObservableValue(item).getValue());
      //  tabelNamaBuah2.getItems().add(item);
      // }
    //tabelNamaBuah2.getColumns().addAll(kolomNamaBuah);
    
  // ambil data dari tabel yang tidak terurut
    ObservableList<String> items  = tabelNamaBuah.getItems();
    
  //konversi observable list ke String
    String[] arrayString = items.toArray(new String[items.size()]);
    
   //konversi arrays String menjadi array int
   int[] arrayInt2 = Arrays.stream(arrayString).mapToInt(Integer::parseInt).toArray();
   
  //urutkan dengan buble sort
  BubbleSort obj = new BubbleSort(arrayInt2);
  
  //simpan kembali data yang sudah terurut
  arrayInt2 = obj.BubbleSort();
 
  
  //konversi ke String array
  String[] arrayTerurutString = 
          Arrays.stream(arrayInt2).mapToObj(String::valueOf
          ).toArray(String[]::new);
  
  //tampilkan ke table yang sudah terurut
  tabelNamaBuah2.getItems().setAll(arrayTerurutString);
  
  // tabelNamaBuah2.getSortOrder().add(kolomNamaBuah);
  // kolomNamaBuah2.setSortType(TableColumn.SortType.ASCENDING);

    }
    
    public void descentingData()
    {
        // TableColumn<String, String> column = kolomNamaBuah; // column you want

      //  List<String> columnData = new ArrayList<>();
      //  for (String item : tabelNamaBuah.getItems()) {
      //  columnData.add(kolomNamaBuah.getCellObservableValue(item).getValue());
      //  tabelNamaBuah2.getItems().add(item);
      // }
    //tabelNamaBuah2.getColumns().addAll(kolomNamaBuah);
    
  // ambil data dari tabel yang tidak terurut
    ObservableList<String> items  = tabelNamaBuah.getItems();
    
  //konversi observable list ke String
    String[] arrayString = items.toArray(new String[items.size()]);
    
   //konversi arrays String menjadi array int
   int[] arrayInt2 = Arrays.stream(arrayString).mapToInt(Integer::parseInt).toArray();
   
  //urutkan dengan buble sort
  BubbleSort2 obj = new BubbleSort2(arrayInt2);
  
  //simpan kembali data yang sudah terurut
  arrayInt2 = obj.BubbleSort2();
 
  
  //konversi ke String array
  String[] arrayTerurutString = 
          Arrays.stream(arrayInt2).mapToObj(String::valueOf
          ).toArray(String[]::new);
  
  //tampilkan ke table yang sudah terurut
  tabelNamaBuah2.getItems().setAll(arrayTerurutString);
  
  // tabelNamaBuah2.getSortOrder().add(kolomNamaBuah);
  // kolomNamaBuah2.setSortType(TableColumn.SortType.ASCENDING);
    }
}
